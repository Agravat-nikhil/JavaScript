const count=true; //pending
let countValue=new Promise(function(resolve,reject){
    resolve('The Operations is resolved now')  //fullfilled
});
console.log(countValue);

