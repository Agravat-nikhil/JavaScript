const count=true; //pending
let countValue=new Promise(function(resolve,reject){
    reject('The Operations is failed now')  //error
});
console.log(countValue);

